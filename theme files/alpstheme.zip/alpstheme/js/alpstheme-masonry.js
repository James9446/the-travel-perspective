jQuery( document ).ready( function( jQuery ) {
	"use strict";
	jQuery( '#main' ).masonry( { columnWidth: 375 } );
} );